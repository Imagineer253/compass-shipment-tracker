# PowerShell script to update landing page with new layout

$newContent = @'
{% extends "base.html" %}

{% block title %}NCPOR Arctic Research Dashboard{% endblock %}

{% block content %}
<!-- Hero Section - Compact -->
<div class="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white py-6 -mx-4 -mt-20 mb-6">
    <div class="max-w-7xl mx-auto px-4 pt-20">
        <div class="text-center">
            <h1 class="text-3xl md:text-5xl font-bold mb-3">🧊 Arctic Research Dashboard</h1>
            <p class="text-lg md:text-xl mb-4">15th Indian Arctic Expedition - Live Monitoring</p>
            <div class="bg-yellow-500 text-black px-3 py-1 rounded-lg inline-block font-semibold text-sm">
                ⚠️ Demo Data - Work in Progress - Not Accurate
            </div>
        </div>
    </div>
</div>

<!-- Main Content Layout - Side by Side -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
    
    <!-- Left Panel - Statistics and Controls -->
    <div class="lg:col-span-1 space-y-6">
        
        <!-- Statistics Cards - Compact -->
        <div class="arctic-card p-4">
            <h2 class="text-xl font-bold text-deep-arctic mb-4 text-center">📊 Expedition Overview</h2>
            <div class="grid grid-cols-2 gap-3">
                <div class="text-center p-3 bg-blue-50 rounded-lg hover:transform hover:scale-105 transition-all duration-300">
                    <div class="text-2xl mb-1">🔬</div>
                    <div class="text-xl font-bold text-deep-arctic">12</div>
                    <div class="text-xs text-gray-600">Projects</div>
                </div>
                <div class="text-center p-3 bg-green-50 rounded-lg hover:transform hover:scale-105 transition-all duration-300">
                    <div class="text-2xl mb-1">🏛️</div>
                    <div class="text-xl font-bold text-deep-arctic">8</div>
                    <div class="text-xs text-gray-600">States</div>
                </div>
                <div class="text-center p-3 bg-purple-50 rounded-lg hover:transform hover:scale-105 transition-all duration-300">
                    <div class="text-2xl mb-1">🎓</div>
                    <div class="text-xl font-bold text-deep-arctic">15</div>
                    <div class="text-xs text-gray-600">Institutes</div>
                </div>
                <div class="text-center p-3 bg-yellow-50 rounded-lg hover:transform hover:scale-105 transition-all duration-300">
                    <div class="text-2xl mb-1">📊</div>
                    <div class="text-xl font-bold text-deep-arctic">247</div>
                    <div class="text-xs text-gray-600">Data Points</div>
                </div>
            </div>
        </div>

        <!-- Map Legend -->
        <div class="arctic-card p-4">
            <h3 class="text-lg font-bold text-deep-arctic mb-3">🗺️ Research Station Types</h3>
            <div class="space-y-2 text-sm">
                <div class="flex items-center space-x-3 p-2 hover:bg-blue-50 rounded transition-all">
                    <div class="w-6 h-6 flex items-center justify-center">🌊</div>
                    <span class="font-medium">CTD Measurements</span>
                </div>
                <div class="flex items-center space-x-3 p-2 hover:bg-blue-50 rounded transition-all">
                    <div class="w-6 h-6 flex items-center justify-center">🧊</div>
                    <span class="font-medium">Ice Core Sampling</span>
                </div>
                <div class="flex items-center space-x-3 p-2 hover:bg-blue-50 rounded transition-all">
                    <div class="w-6 h-6 flex items-center justify-center">🏔️</div>
                    <span class="font-medium">Sediment Coring</span>
                </div>
                <div class="flex items-center space-x-3 p-2 hover:bg-blue-50 rounded transition-all">
                    <div class="w-6 h-6 flex items-center justify-center">💧</div>
                    <span class="font-medium">Water Sampling</span>
                </div>
                <div class="flex items-center space-x-3 p-2 hover:bg-blue-50 rounded transition-all">
                    <div class="w-6 h-6 flex items-center justify-center">🌬️</div>
                    <span class="font-medium">Aerosol Monitoring</span>
                </div>
            </div>
        </div>

        <!-- Map Controls -->
        <div class="arctic-card p-4">
            <h3 class="text-lg font-bold text-deep-arctic mb-3">🎛️ Map Controls</h3>
            <div class="space-y-2">
                <button id="toggleLayers" class="w-full arctic-button text-sm py-2 hover:transform hover:scale-105 transition-all">
                    Hide Research Stations
                </button>
                <button id="satelliteView" class="w-full arctic-button text-sm py-2 hover:transform hover:scale-105 transition-all">
                    Satellite View
                </button>
                <button id="resetView" class="w-full arctic-button text-sm py-2 hover:transform hover:scale-105 transition-all">
                    Reset Map View
                </button>
            </div>
        </div>

        <!-- Quick Access -->
        {% if current_user.is_authenticated %}
        <div class="arctic-card p-4">
            <h3 class="text-lg font-bold text-deep-arctic mb-3">🚀 Quick Access</h3>
            <div class="space-y-2">
                <a href="{{ url_for('main.shipment_type_selection') }}" 
                   class="w-full arctic-button flex items-center justify-center py-3 hover:transform hover:scale-105 transition-all duration-300">
                    📦 Create Shipment
                </a>
                <a href="{{ url_for('main.dashboard') }}" 
                   class="w-full arctic-button flex items-center justify-center py-3 hover:transform hover:scale-105 transition-all duration-300">
                    📊 View Dashboard
                </a>
            </div>
        </div>
        {% else %}
        <div class="arctic-card p-4">
            <h3 class="text-lg font-bold text-deep-arctic mb-3">🔐 System Access</h3>
            <p class="text-sm text-gray-600 mb-3">Login to access COMPASS shipment management</p>
            <a href="{{ url_for('auth.login') }}" 
               class="w-full arctic-button flex items-center justify-center py-3 hover:transform hover:scale-105 transition-all duration-300">
                Login to COMPASS
            </a>
        </div>
        {% endif %}
    </div>

    <!-- Right Panel - Interactive Map -->
    <div class="lg:col-span-2">
        <div class="arctic-card p-4 h-full">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-deep-arctic">🗺️ Arctic Research Locations</h2>
                <div class="text-sm text-gray-500">
                    <span id="stationCount">13</span> Active Stations
                </div>
            </div>
            
            <!-- Map Container - Full Height -->
            <div id="arcticMap" class="w-full rounded-lg border-2 border-gray-200 shadow-lg" style="height: calc(100vh - 280px); min-height: 500px;"></div>
            
            <!-- Status Bar -->
            <div class="mt-3 flex justify-between items-center text-xs text-gray-500">
                <span>Click markers for detailed information</span>
                <span id="mapStatus">Map loaded successfully</span>
            </div>
        </div>
    </div>
</div>

<!-- Leaflet CSS and JS -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>

<!-- Font Awesome for better icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize map
    const map = L.map('arcticMap').setView([78.9, 11.9], 6);
    
    // Base layers
    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        attribution: '© Esri'
    });
    
    // Custom icons using Font Awesome
    function createCustomIcon(iconClass, color, bgColor) {
        return L.divIcon({
            html: `<div style="background-color: ${bgColor}; border: 2px solid ${color}; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.3);">
                     <i class="${iconClass}" style="color: ${color}; font-size: 14px;"></i>
                   </div>`,
            className: 'custom-div-icon',
            iconSize: [30, 30],
            iconAnchor: [15, 15],
            popupAnchor: [0, -15]
        });
    }
    
    // Enhanced research locations
    const locations = [
        // CTD Measurements
        { lat: 78.9, lng: 11.9, type: 'ctd', name: 'Ny-Ålesund CTD Station', 
          description: 'Deep water conductivity, temperature, and depth measurements', 
          depth: '200m', status: 'Active', samples: 45 },
        { lat: 79.1, lng: 12.2, type: 'ctd', name: 'Kongsfjorden CTD', 
          description: 'Fjord water column analysis and monitoring', 
          depth: '150m', status: 'Active', samples: 32 },
        { lat: 78.7, lng: 11.5, type: 'ctd', name: 'Barentsburg CTD', 
          description: 'Coastal water mass characterization', 
          depth: '100m', status: 'Completed', samples: 28 },
        
        // Ice Sampling
        { lat: 79.2, lng: 10.8, type: 'ice', name: 'Sea Ice Station Alpha', 
          description: 'Multi-year ice core drilling and analysis', 
          thickness: '2.5m', status: 'Active', samples: 18 },
        { lat: 79.0, lng: 13.1, type: 'ice', name: 'Ice Edge Station', 
          description: 'First-year ice formation studies', 
          thickness: '1.2m', status: 'Planned', samples: 0 },
        { lat: 78.8, lng: 10.2, type: 'ice', name: 'Fast Ice Station', 
          description: 'Landfast ice dynamics research', 
          thickness: '3.1m', status: 'Active', samples: 22 },
        
        // Sediment Sampling
        { lat: 78.6, lng: 11.8, type: 'sediment', name: 'Seafloor Station 1', 
          description: 'Marine sediment coring for paleoclimate', 
          depth: '300m', status: 'Completed', samples: 15 },
        { lat: 79.3, lng: 12.5, type: 'sediment', name: 'Deep Basin Core', 
          description: 'Long-term climate record extraction', 
          depth: '500m', status: 'Active', samples: 8 },
        
        // Water Sampling
        { lat: 78.95, lng: 11.7, type: 'water', name: 'Surface Water Station', 
          description: 'Microplastic and pollutant analysis', 
          depth: '5m', status: 'Active', samples: 67 },
        { lat: 79.15, lng: 11.3, type: 'water', name: 'Meltwater Station', 
          description: 'Glacier runoff chemistry monitoring', 
          depth: '2m', status: 'Seasonal', samples: 34 },
        { lat: 78.75, lng: 12.8, type: 'water', name: 'Deep Water Station', 
          description: 'Nutrient cycling and biogeochemistry', 
          depth: '400m', status: 'Active', samples: 41 },
        
        // Aerosol Sampling
        { lat: 78.92, lng: 11.93, type: 'aerosol', name: 'Himadri Station', 
          description: 'Continuous atmospheric aerosol monitoring', 
          elevation: '55m', status: 'Continuous', samples: 156 },
        { lat: 79.05, lng: 12.1, type: 'aerosol', name: 'Mountain Station', 
          description: 'High altitude atmospheric composition', 
          elevation: '400m', status: 'Active', samples: 89 }
    ];
    
    // Icon configurations
    const iconConfig = {
        ctd: { icon: 'fas fa-water', color: '#1E40AF', bgColor: '#DBEAFE' },
        ice: { icon: 'fas fa-snowflake', color: '#0EA5E9', bgColor: '#F0F9FF' },
        sediment: { icon: 'fas fa-mountain', color: '#D97706', bgColor: '#FEF3C7' },
        water: { icon: 'fas fa-tint', color: '#059669', bgColor: '#D1FAE5' },
        aerosol: { icon: 'fas fa-wind', color: '#7C3AED', bgColor: '#EDE9FE' }
    };
    
    // Status colors
    const statusColors = {
        'Active': '#10B981',
        'Completed': '#6B7280',
        'Planned': '#F59E0B',
        'Seasonal': '#8B5CF6',
        'Continuous': '#EF4444'
    };
    
    // Add markers to map
    const markers = [];
    locations.forEach(loc => {
        const config = iconConfig[loc.type];
        const marker = L.marker([loc.lat, loc.lng], {
            icon: createCustomIcon(config.icon, config.color, config.bgColor)
        }).bindPopup(`
            <div class="p-4 min-w-72">
                <div class="flex items-center mb-3">
                    <i class="${config.icon}" style="color: ${config.color}; font-size: 18px; margin-right: 8px;"></i>
                    <h3 class="font-bold text-lg text-deep-arctic">${loc.name}</h3>
                </div>
                <p class="text-sm text-gray-600 mb-3">${loc.description}</p>
                <div class="grid grid-cols-2 gap-3 text-xs">
                    <div class="bg-gray-50 p-2 rounded">
                        <strong>Type:</strong><br>
                        <span style="color: ${config.color}">${loc.type.toUpperCase()}</span>
                    </div>
                    <div class="bg-gray-50 p-2 rounded">
                        <strong>Status:</strong><br>
                        <span style="color: ${statusColors[loc.status]}">${loc.status}</span>
                    </div>
                    ${loc.depth ? `<div class="bg-gray-50 p-2 rounded"><strong>Depth:</strong><br>${loc.depth}</div>` : ''}
                    ${loc.thickness ? `<div class="bg-gray-50 p-2 rounded"><strong>Ice Thickness:</strong><br>${loc.thickness}</div>` : ''}
                    ${loc.elevation ? `<div class="bg-gray-50 p-2 rounded"><strong>Elevation:</strong><br>${loc.elevation}</div>` : ''}
                    <div class="bg-gray-50 p-2 rounded">
                        <strong>Samples:</strong><br>${loc.samples}
                    </div>
                    <div class="bg-gray-50 p-2 rounded col-span-2">
                        <strong>Coordinates:</strong><br>${loc.lat.toFixed(4)}, ${loc.lng.toFixed(4)}
                    </div>
                </div>
            </div>
        `).addTo(map);
        markers.push(marker);
    });
    
    // Control functionality
    let layersVisible = true;
    let currentLayer = osmLayer;
    
    document.getElementById('toggleLayers').addEventListener('click', function() {
        if (layersVisible) {
            markers.forEach(marker => map.removeLayer(marker));
            this.textContent = 'Show Research Stations';
            document.getElementById('stationCount').textContent = '0';
        } else {
            markers.forEach(marker => map.addLayer(marker));
            this.textContent = 'Hide Research Stations';
            document.getElementById('stationCount').textContent = locations.length;
        }
        layersVisible = !layersVisible;
    });
    
    document.getElementById('satelliteView').addEventListener('click', function() {
        if (currentLayer === osmLayer) {
            map.removeLayer(osmLayer);
            map.addLayer(satelliteLayer);
            currentLayer = satelliteLayer;
            this.textContent = 'Street Map View';
        } else {
            map.removeLayer(satelliteLayer);
            map.addLayer(osmLayer);
            currentLayer = osmLayer;
            this.textContent = 'Satellite View';
        }
    });
    
    document.getElementById('resetView').addEventListener('click', function() {
        map.setView([78.9, 11.9], 6);
        document.getElementById('mapStatus').textContent = 'Map view reset';
        setTimeout(() => {
            document.getElementById('mapStatus').textContent = 'Map loaded successfully';
        }, 2000);
    });
    
    // Add scale control
    L.control.scale({
        position: 'bottomright',
        metric: true,
        imperial: false
    }).addTo(map);
    
    // Map event listeners
    map.on('zoomend', function() {
        document.getElementById('mapStatus').textContent = `Zoom level: ${map.getZoom()}`;
        setTimeout(() => {
            document.getElementById('mapStatus').textContent = 'Map loaded successfully';
        }, 2000);
    });
});
</script>

<style>
/* Custom map styles */
#arcticMap {
    background: linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%);
}

.leaflet-popup-content-wrapper {
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    max-width: 350px;
}

.leaflet-popup-content {
    margin: 0;
    line-height: 1.4;
}

.custom-div-icon {
    background: transparent !important;
    border: none !important;
}

/* Responsive adjustments */
@media (max-width: 1024px) {
    #arcticMap {
        height: 400px !important;
        min-height: 400px !important;
    }
}

@media (max-width: 768px) {
    #arcticMap {
        height: 350px !important;
        min-height: 350px !important;
    }
}

/* Smooth transitions for all interactive elements */
.arctic-card, .arctic-button {
    transition: all 0.3s ease;
}

.arctic-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(31, 38, 135, 0.15);
}
</style>

{% endblock %}
'@

# Write the new content to the file
$newContent | Out-File -FilePath "compass\templates\landing.html" -Encoding UTF8

Write-Host "✓ Landing page updated with new side-by-side layout!" 