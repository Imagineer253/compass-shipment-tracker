"""Add 2FA and email verification fields

Revision ID: cfa1e56ddef1
Revises: f192dea0a662
Create Date: 2025-08-06 23:31:21.778882

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'cfa1e56ddef1'
down_revision = 'f192dea0a662'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
